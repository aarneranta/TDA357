SET SCHEMA 'ex2';
------
SELECT albumId 
FROM Albums
WHERE yearReleased >= '1/1/2016';

--------
SELECT track 
FROM TracksOnAlbum
WHERE album IN (
	SELECT albumId 
	FROM Albums
	WHERE yearReleased >= '1/1/2016'
	);

---------
SELECT *
FROM Tracks
WHERE trackId IN(
SELECT track 
		FROM TracksOnAlbum
		WHERE album IN (
			SELECT albumId 
			FROM Albums
			WHERE yearReleased >= '1/1/2016'
			));

----------
SELECT artist FROM
Participates WHERE track IN (
	SELECT track 
	FROM TracksOnAlbum
	WHERE album IN (
		SELECT albumId 
		FROM Albums
		WHERE yearReleased >= '1/1/2016'
		)
	);


----------
SELECT * 
FROM Artists
WHERE artistId IN (
	SELECT artist FROM
	Participates WHERE track IN (
		SELECT track 
		FROM TracksOnAlbum
		WHERE album IN (
			SELECT albumId 
			FROM Albums
			WHERE yearReleased >= '1/1/2016'
			)
		)
	);