SET SCHEMA 'airtraffic';

-----------------------
CREATe VIEW airtraffic.connectedCities AS
SELECT A1.city as origin,
       A2.city as destination,
       departureTime, arrivalTime, 1 as legs,
       arrivalTime - departureTime as totalTravelTime,
       arrivalTime - departureTime as totalTimeInAir
  FROM airtraffic.Flights, airtraffic.Airports as A1, airtraffic.Airports as A2
  WHERE departureAirport = A1.code
    AND destinationAirport = A2.code
UNION
SELECT A1.city as origin,
       A2.city as destination,
       F1.departureTime, F2.arrivalTime, 2 as legs,
       F2.arrivalTime - F1.departureTime as totalTravelTime,
       F1.arrivalTime - F1.departureTime
        + (F2.arrivalTime - F2.departureTime)
        as totalTimeInAir
  FROM airtraffic.Flights as F1, airtraffic.Flights as F2,
       airtraffic.Airports as A1, airtraffic.Airports as A2
  WHERE F1.departureAirport = A1.code
    AND F2.destinationAirport = A2.code
    AND F1.destinationAirport = F2.departureAirport
    AND F2.departureTime > F1.arrivalTime
ORDER BY origin, destination, departureTime, arrivalTime, legs;

-- We can also use the following. 
-- Find all the needed data first (those that are not needed to be calculated or in other words already available in the tables), which is in this case list "CityFlights".
-- Then compute TotalTravelTime and totalTimeInAir
-- ORDER BY is not asked, but it would make it easier for us to look at the result (I added it here).
-- This is very similar to the sample solution of VT2015; but with departureTime and arrivalTime which were missing in the sample solution

CREATE VIEW airtraffic.Connections AS
WITH
  CityFlights AS
  (SELECT departureAirport, D.city AS departureCity, destinationAirport,
		A.city AS destinationCity, departureTime, arrivalTime
   FROM airtraffic.Flights, airtraffic.Airports AS D, airtraffic.Airports AS A
   WHERE D.code = departureAirport AND A.code = destinationAirport)

  SELECT origin, destination, departureTime, arrivalTime, legs, totalTravelTime, totalTimeInAir
  FROM
  ((SELECT departureCity AS origin, destinationCity AS destination,
		   departureTime, arrivalTime, 1 AS legs,
		   arrivalTime - departureTime AS totalTravelTime,
           arrivalTime - departureTime AS totalTimeInAir           
    FROM CityFlights)
  UNION
   (SELECT F1.departureCity AS origin, F2.destinationCity AS destination,
           F1.departureTime, F2.arrivalTime, 2 AS legs,
		   F2.arrivalTime - F1.departureTime AS totalTravelTime,
           (F2.arrivalTime - F1.departureTime) - (F2.departureTime - F1.arrivalTime) as totalTimeInAir
    FROM CityFlights F1 JOIN CityFlights F2 ON F1.destinationAirport = F2.departureAirport
    WHERE F1.arrivalTime < F2.departureTime)
  ) AS F 
  ORDER BY origin, destination, departureTime, arrivalTime, legs;