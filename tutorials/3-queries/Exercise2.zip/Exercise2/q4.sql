SET SCHEMA 'ex2';

SELECT * 
FROM tracks
ORDER BY length DESC;

--------

SELECT *
FROM tracks
WHERE length IN (
	SELECT MAX(length)
	FROM tracks
	);
	
---------
SELECT * 
FROM TracksOnAlbum
WHERE track IN (
	SELECT trackId
	FROM tracks
	WHERE length IN (
		SELECT MAX(length)
		FROM tracks
		)
	);
	
--------

SELECT * 
FROM Albums
WHERE albumId IN (
	SELECT album
	FROM TracksOnAlbum
	WHERE track IN (
		SELECT trackId
		FROM tracks
		WHERE length IN (
			SELECT MAX(length)
			FROM tracks
			)
		)
	);


---------
SELECT tracks.title as TrackTitle, tracks.length as TrackLength, albums.title as AlbumTitle, albums.yearReleased 
FROM tracks
INNER JOIN (
	SELECT * 
	FROM TracksOnAlbum
	WHERE track IN (
		SELECT trackId
		FROM tracks
		WHERE length IN (
			SELECT MAX(length)
			FROM tracks
			)
		)
) s
ON trackId = s.track
INNER JOIN Albums
ON album = albumId
ORDER BY yearReleased DESC;


-----------

SELECT max(yearReleased) as yearReleased
FROM Albums;



-----------
SELECT tracks.title as TrackTitle, tracks.length as TrackLength, albums.title as AlbumTitle, albums.yearReleased 
FROM tracks
INNER JOIN (
	SELECT * 
	FROM TracksOnAlbum
	WHERE track IN (
		SELECT trackId
		FROM tracks
		WHERE length IN (
			SELECT MAX(length)
			FROM tracks
			)
		)
) s
ON trackId = s.track
INNER JOIN Albums
ON album = albumId
INNER JOIN (
    select max(yearReleased) as yearReleased
    from Albums
) tm
ON tm.yearReleased = Albums.yearReleased
ORDER BY yearReleased DESC;
