SET SCHEMA 'airtraffic';

-----------------------
SELECT distinct airport
FROM (
  (SELECT destinationAirport as airport, airlineName
   FROM airtraffic.Flights JOIN airtraffic.FlightCodes ON airtraffic.Flights.code = airtraffic.FlightCodes.code)
  UNION
  (SELECT departureAirport as airport, airlineName
   FROM airtraffic.Flights JOIN airtraffic.FlightCodes ON airtraffic.Flights.code = airtraffic.FlightCodes.code)
) as destDepartAirports
WHERE destDepartAirports.airlineName like 'Lufthansa%'
   OR destDepartAirports.airlineName like 'Scandinavian%'
ORDER BY airport;

-----------------------
SELECT distinct airport
FROM ( (SELECT distinct(departureAirport)
        FROM airtraffic.Flights, (select code as fcode from airtraffic.FlightCodes where airlineName like 'Lufthansa%' or airlineName like 'Scandinavian%') S
        WHERE code = fcode)
       UNION
       (SELECT distinct(destinationAirport)
        FROM airtraffic.Flights, (select code as fcode from airtraffic.FlightCodes where airlineName like 'Lufthansa%' or airlineName like 'Scandinavian%') S
        WHERE code = fcode)
) as airport;