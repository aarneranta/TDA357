SET SCHEMA 'ex2';

SELECT * 
FROM Tracks;

---------
SELECT *
FROM PlayLog;

---------
SELECT track, COUNT(username) AS timesplayed, COUNT(DISTINCT username) AS differentUsers
FROM PlayLog
GROUP BY track;

---------
SELECT * 
FROM Tracks 
INNER JOIN PLayLog
ON trackId=track;

---------
SELECT trackId, title, COUNT(username) AS timesplayed, COUNT(DISTINCT username) AS differentUsers
FROM PlayLog
RIGHT JOIN Tracks
ON trackId = track
GROUP BY trackId, title;
