SET SCHEMA 'ex2';

SELECT * 
FROM PlayLists;

--------------
SELECT username, COUNT(playlistname) 
FROM PlayLists
GROUP BY (username);