SET SCHEMA 'airtraffic';

-----------------------
SELECT city, count(f.code) as noofflights
FROM airtraffic.Airports a, airtraffic.Flights f
WHERE a.code = f.departureAirport
GROUP BY city
ORDER BY noofflights desc;